import boto3
import json
import requests

# Create a Lambda function that will be triggered by GitHub webhook
def lambda_handler(event, context):
    # Get the payload from the webhook
    payload = json.loads(event["body"])
    
    # Check if the event is a pull request merged event
    if payload["action"] == "closed" and payload["pull_request"]["merged"]:
        # Get the repository name and the pull request number
        repo_name = payload["repository"]["name"]
        pr_number = payload["pull_request"]["number"]
        
        # Get the list of files that were changed in the pull request
        files_url = payload["pull_request"]["url"] + "/files"
        files_response = requests.get(files_url)
        files_data = files_response.json()
        files_list = [file["filename"] for file in files_data]
        
        # Log the repository name and the files list to CloudWatch
        print(f"Repository: {repo_name}")
        print(f"Pull request: {pr_number}")
        print(f"Files changed: {files_list}")
        
    # Return a 200 OK response to GitHub
    return {
        "statusCode": 200,
        "body": "OK"
    }